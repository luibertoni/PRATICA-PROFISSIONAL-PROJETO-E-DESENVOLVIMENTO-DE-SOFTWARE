package estacionamento;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class connection {

    private final String url = "jdbc:postgresql://localhost:5432/postgres";
    private final String user = "postgres";
    private final String password = "postgres";

    public void initialize() {
        try {
            //DriverManager.registerDriver(new org.postgresql.Driver()); 
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found " + e);
        }
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            Statement stmt = con.createStatement();
            //ResultSet rs = stmt.executeQuery("SELECT * FROM carros WHERE carros.placa = '" + placa + "'");
            ResultSet rs = stmt.executeQuery("SELECT * FROM carros");
            System.out.println("placa");

            while (rs.next()) {
                String id = rs.getString("placa");
                System.out.println(id );
            }
            
        } catch (SQLException e) {
            System.out.println("SQL exception occured" + e);
        }
        
    }
    
    public ArrayList getVagas(String clausula){
        
        ArrayList<Vaga> List = new ArrayList<Vaga>();
        
                
        try {
            //DriverManager.registerDriver(new org.postgresql.Driver()); 
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found " + e);
        }
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            Statement stmt = con.createStatement();
            //ResultSet rs = stmt.executeQuery("SELECT * FROM carros WHERE carros.placa = '" + placa + "'");
            ResultSet rs = stmt.executeQuery(clausula);            

            while (rs.next()) {
                
                Vaga vg = new Vaga(0);
                
                vg.setId(rs.getInt("ID"));
                vg.setAndar(rs.getShort("Andar"));
                vg.setRua(rs.getString("Rua"));
                vg.setNumero(rs.getInt("Numero"));
                vg.setTipo(rs.getString("Tipo"));
                vg.setEstado(rs.getBoolean("Estado"));
                
                List.add(vg);
                
            }
            
        } catch (SQLException e) {
            System.out.println("SQL exception occured" + e);
        }
        
        return List;
        
    }
    
}