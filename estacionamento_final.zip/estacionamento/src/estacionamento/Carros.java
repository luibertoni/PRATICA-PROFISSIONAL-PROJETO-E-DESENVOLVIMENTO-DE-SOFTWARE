/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estacionamento;

import java.io.Serializable;
import java.util.Collection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/**
 *
 * @author Luigi
 */
public class Carros implements Serializable {

    private final String url = "jdbc:postgresql://localhost:5432/postgres";
    private final String user = "postgres";
    private final String password = "postgres";
    private String placa;
    private String marca;
    private String modelo;
    private String cor;
    private Collection<Registro> registroCollection;

    public Carros(String placa) {
        this.placa = placa;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public ArrayList getCarros(String clausula){
        
        ArrayList<Carros> List = new ArrayList<Carros>();
        
                
        try {
            //DriverManager.registerDriver(new org.postgresql.Driver()); 
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found " + e);
        }
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(clausula);            

            while (rs.next()) {
                
                Carros car = new Carros("");
                
                car.setPlaca(rs.getString("placa"));
                car.setMarca(rs.getString("marca"));
                car.setModelo(rs.getString("modelo"));
                car.setCor(rs.getString("cor"));
                
                List.add(car);
                
            }
            
        } catch (SQLException e) {
            System.out.println("SQL exception occured" + e);
        }
        
        return List;
        
    }
    
    public String registrar_veiculo(){
        
        String clausula;
        
        ArrayList<Carros> carro = this.getCarros("SELECT * from carros where carros.placa = '" + this.placa + "'");
        
        if (carro.isEmpty()){
        
            clausula = "INSERT INTO carros (placa, marca, modelo, cor) VALUES ('" + this.placa + "', '" + this.marca + "', '" + this.modelo + "', '" + this.cor + "')";
        
            try {
                //DriverManager.registerDriver(new org.postgresql.Driver()); 
                Class.forName("org.postgresql.Driver");
            } catch (ClassNotFoundException e) {
                System.out.println("Class not found " + e);
            }
            try {
                Connection con = DriverManager.getConnection(url, user, password);
                Statement stmt = con.createStatement();
                stmt.executeQuery(clausula);                            

            } catch (SQLException e) {
                System.out.println("SQL exception occured" + e);
            }
        }
        return null;
    }
    
}
