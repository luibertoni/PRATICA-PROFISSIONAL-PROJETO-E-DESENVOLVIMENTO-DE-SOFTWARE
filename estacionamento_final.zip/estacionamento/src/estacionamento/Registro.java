/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estacionamento;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Luigi
 */
public class Registro implements Serializable {
    
    private final String url = "jdbc:postgresql://localhost:5432/postgres";
    private final String user = "postgres";
    private final String password = "postgres";

    private static final long serialVersionUID = 1L;
    private Integer id;
    private Date diaEntrada;
    private Date horaEntrada;
    private Date diaSaida;
    private Date horaSaida;
    private Float valorUso;
    private Float horaAdicional;
    private Float total;
    private String placa;
    private Integer idVaga;
    private Integer tolerancia;

    public Registro() {
    }

    public Registro(Integer id) {
        this.id = id;
    }

    public Registro(Integer id, Date diaEntrada, Date horaEntrada) {
        this.id = id;
        this.diaEntrada = diaEntrada;
        this.horaEntrada = horaEntrada;
    }
    
    public Registro(int idVaga, String placa, String marca, String cor, String modelo) {
        
        Carros car = new Carros("");
        
        /*this.horaEntrada = horaEntrada;*/
        this.idVaga      = idVaga;
        this.placa       = placa;
        this.idVaga      = idVaga;
        car.setPlaca(placa);
        car.setMarca(marca);
        car.setModelo(modelo);
        car.setCor(cor);

        car.registrar_veiculo();        
        
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDiaEntrada() {
        return diaEntrada;
    }

    public void setDiaEntrada(Date diaEntrada) {
        this.diaEntrada = diaEntrada;
    }

    public Date getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(Date horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public Date getDiaSaida() {
        return diaSaida;
    }

    public void setDiaSaida(Date diaSaida) {
        this.diaSaida = diaSaida;
    }

    public Date getHoraSaida() {
        return horaSaida;
    }

    public void setHoraSaida(Date horaSaida) {
        this.horaSaida = horaSaida;
    }

    public Float getValorUso() {
        return valorUso;
    }

    public void setValorUso(Float valorUso) {
        this.valorUso = valorUso;
    }

    public Float getHoraAdicional() {
        return horaAdicional;
    }

    public void setHoraAdicional(Float horaAdicional) {
        this.horaAdicional = horaAdicional;
    }

    public Float getTotal() {
        return total;
    }

    public void setTotal(Float total) {
        this.total = total;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public Integer getIdVaga() {
        return idVaga;
    }

    public void setIdVaga(Integer idVaga) {
        this.idVaga = idVaga;
    }  
    
    public ArrayList getRegistro(String clausula){
        
        ArrayList<Registro> List = new ArrayList<Registro>();        
                
        try {
            //DriverManager.registerDriver(new org.postgresql.Driver()); 
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found " + e);
        }
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(clausula);            

            while (rs.next()) {
                
                Registro reg = new Registro(0);
                
                reg.setId(rs.getInt("ID"));
                reg.setPlaca(rs.getString("placa"));
                reg.setDiaEntrada(rs.getDate("dia_entrada"));
                reg.setHoraEntrada(rs.getTime("hora_entrada"));
                reg.setDiaSaida(rs.getDate("dia_saida"));
                reg.setHoraSaida(rs.getTime("hora_saida"));
                reg.setValorUso(rs.getFloat("valor_uso"));
                reg.setHoraAdicional(rs.getFloat("hora_adicional"));
                reg.setTotal(rs.getFloat("total"));
                reg.setIdVaga(rs.getInt("id_vaga"));                
                
                List.add(reg);
                
            }
            
        } catch (SQLException e) {
            System.out.println("SQL exception occured" + e);
        }
        
        return List;
        
    }
    
    public String registrar_entrada()
    {
               
        String clausula;
        
        Taxas tx = new Taxas();
        ArrayList<Taxas> taxas = tx.getTaxa("SELECT * from taxas");
        
        Registro reg = new Registro();
        ArrayList<Registro> registro = reg.getRegistro("SELECT * from registro WHERE registro.placa = '" + this.placa + "' AND registro.hora_saida is null");
        
        if (registro.isEmpty()){
            
            clausula = "INSERT INTO registro (id_vaga, placa, dia_entrada, hora_entrada, valor_uso, hora_adicional) VALUES (" + this.idVaga + ", '" + this.placa + "', CURRENT_DATE, CURRENT_TIME, " + taxas.get(0).getValorUso().replace("R$", "").replace(" ", "").replace(",", ".") + ", " + taxas.get(0).getAdicionalHora().replace("R$", "").replace(" ", "").replace(",", ".") + ")";

            System.out.println(clausula);

            try {
                //DriverManager.registerDriver(new org.postgresql.Driver()); 
                Class.forName("org.postgresql.Driver");
            } catch (ClassNotFoundException e) {
                System.out.println("Class not found " + e);
            }
            try {
                Connection con = DriverManager.getConnection(url, user, password);
                Statement stmt = con.createStatement();
                stmt.executeQuery(clausula);
            } catch (SQLException e) {
                System.out.println("SQL exception occured" + e);
            }    
           
        }
        
        return null;
        
    }
    
    public String registrar_saida()
    {
               
        String clausula;
        
        Registro reg = new Registro();
        ArrayList<Registro> registros = reg.getRegistro("SELECT * from registro where registro.placa ='" + this.placa + "' AND hora_saida is null ");
        
        if (!registros.isEmpty()){
            
            clausula = "UPDATE registro SET dia_saida = CURRENT_DATE, hora_saida = CURRENT_TIME WHERE registro.id = " + Integer.toString(registros.get(0).getId());
            
            System.out.println(clausula);

            try {
                //DriverManager.registerDriver(new org.postgresql.Driver()); 
                Class.forName("org.postgresql.Driver");
            } catch (ClassNotFoundException e) {
                System.out.println("Class not found " + e);
            }
            try {
                Connection con = DriverManager.getConnection(url, user, password);
                Statement stmt = con.createStatement();
                stmt.executeQuery(clausula);
            } catch (SQLException e) {
                System.out.println("SQL exception occured" + e);
            }
            
        }    
        
        return null;
        
    }
    
}
