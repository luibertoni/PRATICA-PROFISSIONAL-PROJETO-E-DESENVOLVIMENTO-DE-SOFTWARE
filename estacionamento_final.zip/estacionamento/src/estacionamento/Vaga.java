/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estacionamento;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Luigi
 */
public class Vaga implements Serializable {
    
    private final String url = "jdbc:postgresql://localhost:5432/postgres";
    private final String user = "postgres";
    private final String password = "postgres";

    private Integer id;
    private Short andar;
    private String rua;
    private Integer numero;
    private String tipo;
    private Boolean estado;    

    public Vaga(Integer ID, Short Andar, String Rua, Integer Numero, String Tipo, Boolean Estado) {
        this.setId(ID);
        this.setAndar(Andar);
        this.setRua(Rua);
        this.setNumero(Numero);
        this.setTipo(Tipo);
        this.setEstado(Estado);
    }

    public Vaga(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Short getAndar() {
        return andar;
    }

    public void setAndar(Short andar) {
        this.andar = andar;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }    
    
    public ArrayList getVagas(String clausula){
        
        ArrayList<Vaga> List = new ArrayList<Vaga>();
        
                
        try {
            //DriverManager.registerDriver(new org.postgresql.Driver()); 
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found " + e);
        }
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            Statement stmt = con.createStatement();
            //ResultSet rs = stmt.executeQuery("SELECT * FROM carros WHERE carros.placa = '" + placa + "'");
            ResultSet rs = stmt.executeQuery(clausula);            

            while (rs.next()) {
                
                Vaga vg = new Vaga(0);
                
                vg.setId(rs.getInt("ID"));
                vg.setAndar(rs.getShort("Andar"));
                vg.setRua(rs.getString("Rua"));
                vg.setNumero(rs.getInt("Numero"));
                vg.setTipo(rs.getString("Tipo"));
                vg.setEstado(rs.getBoolean("Estado"));
                
                List.add(vg);
                
            }
            
        } catch (SQLException e) {
            System.out.println("SQL exception occured" + e);
        }
        
        return List;
        
    }
    
}
