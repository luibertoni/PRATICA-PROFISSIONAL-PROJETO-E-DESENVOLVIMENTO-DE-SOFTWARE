/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estacionamento;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


/**
 *
 * @author Luigi
 */

public class Taxas implements Serializable {
    
    private final String url = "jdbc:postgresql://localhost:5432/postgres";
    private final String user = "postgres";
    private final String password = "postgres";

    private String valorUso;
    private String adicionalHora;
    private int tolerancia;
    private int id;

    public Taxas() {
    }

    public String getValorUso() {
        return valorUso;
    }

    public void setValorUso(String valorUso) {
        this.valorUso = valorUso;
    }

    public String getAdicionalHora() {
        return adicionalHora;
    }

    public void setAdicionalHora(String adicionalHora) {
        this.adicionalHora = adicionalHora;
    }

    public int getTolerancia() {
        return tolerancia;
    }

    public void setTolerancia(int tolerancia) {
        this.tolerancia = tolerancia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList getTaxa(String clausula){
        
        ArrayList<Taxas> List = new ArrayList<Taxas>();
        
                
        try {
            //DriverManager.registerDriver(new org.postgresql.Driver()); 
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found " + e);
        }
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            Statement stmt = con.createStatement();
            //ResultSet rs = stmt.executeQuery("SELECT * FROM carros WHERE carros.placa = '" + placa + "'");
            ResultSet rs = stmt.executeQuery(clausula);            

            while (rs.next()) {
                
                Taxas tx = new Taxas();
                
                tx.setId(rs.getInt("ID"));
                tx.setAdicionalHora(rs.getString("adicional_hora"));
                tx.setValorUso(rs.getString("valor_uso"));
                tx.setTolerancia(rs.getInt("tolerancia"));
                
                List.add(tx);
                
            }
            
        } catch (SQLException e) {
            System.out.println("SQL exception occured" + e);
        }
        
        return List;
        
    }
    
}
