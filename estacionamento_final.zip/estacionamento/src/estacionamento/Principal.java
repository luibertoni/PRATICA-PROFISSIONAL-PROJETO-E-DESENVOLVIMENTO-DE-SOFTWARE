/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package estacionamento;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import javax.swing.JTable;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author Luigi
 */
public class Principal extends javax.swing.JFrame {

    /**
     * Creates new form Principal
     */
    private final String url = "jdbc:postgresql://localhost:5432/postgres";
    private final String user = "postgres";
    private final String password = "postgres";
    
    public Principal() {
        initComponents();
        dispSelectTipoVaga.setSelectedIndex(4);
        dispSelectEstadoVaga.setSelectedIndex(2);
        abasPrincipais.setEnabledAt(1,false);
        abasPrincipais.setEnabledAt(2,false);
        PopulaVagas();
        inputEntradaPlaca.getDocument().addDocumentListener(new DocumentListener(){
            @Override
            public void insertUpdate(DocumentEvent e) {
                int tamanho = inputEntradaPlaca.getText().length();
                
                if (7 == tamanho) {

                    Carros car = new Carros("");
                    ArrayList<Carros> carro = car.getCarros("SELECT * FROM carros WHERE carros.placa = '" + inputEntradaPlaca.getText() + "'");

                    if (!carro.isEmpty()){
                        
                        inputEntradaCor.setText(carro.get(0).getCor());
                        inputEntradaMarca.setText(carro.get(0).getMarca());
                        inputEntradaModelo.setText(carro.get(0).getModelo());
                    }
                    else{
                        
                        inputEntradaCor.setText("");
                        inputEntradaMarca.setText("");
                        inputEntradaModelo.setText("");
                        inputEntradaCor.setEditable(true);
                        inputEntradaMarca.setEditable(true);
                        inputEntradaModelo.setEditable(true);
                    }

                }
                else if (tamanho > 7){
                    /*inputEntradaPlaca.setText(inputEntradaPlaca.getText().substring(0, 6));*/
                }
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                
            }
        });
    }
    
    public void PopulaVagas(){
        
        DefaultTableModel model = (DefaultTableModel) dispTabelaVagas.getModel(); 
        model.setRowCount(0);
        Vaga vg = new Vaga(0);
        ArrayList<Vaga> vagas = vg.getVagas("SELECT * from vaga ORDER BY vaga.estado desc");
        
        int countOcupadas = 0;
        
        selectEntradaVaga.removeAllItems();
        selectEntradaVaga.addItem("");
        dispSaidaVaga.removeAllItems();
        dispSaidaVaga.addItem("");
        
        for (Integer i = 0; i < vagas.size(); i++){
            
            Object rowModel[] = new Object[7];
            
            /*rowModel[1] = vagas.get(i).getId();*/
            rowModel[0] = vagas.get(i).getAndar();
            rowModel[1] = vagas.get(i).getRua();
            rowModel[2] = vagas.get(i).getNumero();
            rowModel[3] = vagas.get(i).getTipo();
            
            if (vagas.get(i).getEstado()) {
                rowModel[4] = "Ocupado";
                PopulaRegistro(vagas.get(i).getId(), rowModel);
                countOcupadas++;
            }
            else {
                rowModel[4] = "Livre";
            }
            
            model.addRow(rowModel);
            
            selectEntradaVaga.addItem(vagas.get(i).getNumero().toString());
            dispSaidaVaga.addItem(vagas.get(i).getNumero().toString());
            
        }
        dispTotalVagas.setText(Integer.toString(vagas.size()));
        dispVagasOcupadas.setText(Integer.toString(countOcupadas));
        dispVagasLivres.setText(Integer.toString(vagas.size() - countOcupadas));
        
        progressBar.setMaximum(vagas.size());
        progressBar.setValue(countOcupadas);
        
    }
    
    private void PopulaRegistro(Integer id, Object rowModel[]) {
        
        Registro reg = new Registro(0);
        ArrayList<Registro> registros = reg.getRegistro("SELECT * from registro where registro.id_vaga = " + id.toString());
        
        for (Integer j = 0; j < registros.size(); j++){            
            /*rowModel[1] = registros.get(i).getId();*/
            rowModel[5] = registros.get(j).getPlaca();
            rowModel[6] = registros.get(j).getHoraEntrada();
        }
        
    }
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane3 = new javax.swing.JTabbedPane();
        jMenu1 = new javax.swing.JMenu();
        abasPrincipais = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        progressBar = new javax.swing.JProgressBar();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        dispTotalVagas = new javax.swing.JTextField();
        dispVagasOcupadas = new javax.swing.JTextField();
        dispVagasLivres = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        dispTabelaVagas = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        dispSelectEstadoVaga = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        dispSelectTipoVaga = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        inputEntradaModelo = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        inputEntradaMarca = new javax.swing.JTextField();
        inputEntradaCor = new javax.swing.JTextField();
        inputEntradaPlaca = new javax.swing.JTextField();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        selectEntradaTipoVaga = new javax.swing.JComboBox<>();
        selectEntradaVaga = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        inputEntradaEntrada = new javax.swing.JTextField();
        dispEntradaValorHora = new javax.swing.JTextField();
        dispEntradaUso = new javax.swing.JTextField();
        dispEntradaTolerncia = new javax.swing.JTextField();
        botaoEntradaSalvar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        botaoSaidaSalvar = new javax.swing.JButton();
        jTabbedPane7 = new javax.swing.JTabbedPane();
        jPanel10 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        dispSaidaModelo = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        dispSaidaMarca = new javax.swing.JTextField();
        dispSaidaCor = new javax.swing.JTextField();
        dispSaidaPlaca = new javax.swing.JTextField();
        jTabbedPane8 = new javax.swing.JTabbedPane();
        jPanel11 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        dispSaidaTipoVaga = new javax.swing.JComboBox<>();
        dispSaidaVaga = new javax.swing.JComboBox<>();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        dispSaidaEntrada = new javax.swing.JTextField();
        dispSaidaValorHora = new javax.swing.JTextField();
        dispSaidaUso = new javax.swing.JTextField();
        dispSaidaTolerancia = new javax.swing.JTextField();
        inputSaidaSaida = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        dispSaidaTotal = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        abasPrincipais.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        abasPrincipais.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                abasPrincipaisFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                abasPrincipaisFocusLost(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        progressBar.setBackground(new java.awt.Color(51, 181, 0));
        progressBar.setForeground(new java.awt.Color(0, 0, 122));
        progressBar.setValue(75);

        jLabel29.setText("Ocupadas");

        jLabel30.setText("Livres");

        jLabel31.setText("Total");

        dispTotalVagas.setEditable(false);
        dispTotalVagas.setText("100");

        dispVagasOcupadas.setEditable(false);
        dispVagasOcupadas.setText("60");
        dispVagasOcupadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dispVagasOcupadasActionPerformed(evt);
            }
        });

        dispVagasLivres.setEditable(false);
        dispVagasLivres.setText("40");

        jLabel3.setText("S.C.E.");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addGap(171, 171, 171)
                        .addComponent(jLabel29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dispVagasOcupadas, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 107, Short.MAX_VALUE)
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dispVagasLivres, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(111, 111, 111)
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dispTotalVagas, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(progressBar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(jLabel30)
                    .addComponent(jLabel31)
                    .addComponent(dispTotalVagas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dispVagasOcupadas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dispVagasLivres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        dispTabelaVagas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Andar", "Rua", "Número", "Tipo", "Estado", "Placa", "Entrada"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        dispTabelaVagas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dispTabelaVagasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dispTabelaVagas);

        jLabel1.setText("Estado");

        dispSelectEstadoVaga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Livre", "Ocupada", "Todas" }));
        dispSelectEstadoVaga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dispSelectEstadoVagaActionPerformed(evt);
            }
        });

        jLabel2.setText("Tipo");

        dispSelectTipoVaga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Comum", "Deficiente", "Idoso", "Grávida", "Todas" }));
        dispSelectTipoVaga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dispSelectTipoVagaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dispSelectTipoVaga, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dispSelectEstadoVaga, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(dispSelectEstadoVaga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(dispSelectTipoVaga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        abasPrincipais.addTab("Mapa de Vagas", jPanel1);

        jLabel5.setText("Placa");

        jLabel6.setText("Modelo");

        inputEntradaModelo.setEditable(false);

        jLabel7.setText("Cor");

        jLabel8.setText("Marca");

        inputEntradaMarca.setEditable(false);

        inputEntradaCor.setEditable(false);

        inputEntradaPlaca.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                inputEntradaPlacaInputMethodTextChanged(evt);
            }
        });
        inputEntradaPlaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputEntradaPlacaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(inputEntradaModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(inputEntradaCor, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel8))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(inputEntradaMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(inputEntradaPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(544, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(inputEntradaPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inputEntradaMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(inputEntradaModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(inputEntradaCor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Veículo", jPanel7);

        jLabel9.setText("Entrada");

        selectEntradaTipoVaga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Comum", "Deficiente", "Idoso", "Grávida", "Todas" }));

        selectEntradaVaga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel10.setText("Tipo Vaga");

        jLabel11.setText("Vaga");

        jLabel12.setText("Uso");

        jLabel13.setText("Valor Hora");

        jLabel14.setText("Tolerância");

        inputEntradaEntrada.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inputEntradaEntradaMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(inputEntradaEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(selectEntradaTipoVaga, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(selectEntradaVaga, javax.swing.GroupLayout.Alignment.LEADING, 0, 206, Short.MAX_VALUE))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(dispEntradaUso, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dispEntradaValorHora, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(dispEntradaTolerncia, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(450, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(inputEntradaEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(selectEntradaTipoVaga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(selectEntradaVaga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(dispEntradaTolerncia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(dispEntradaValorHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dispEntradaUso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("Registro", jPanel5);

        botaoEntradaSalvar.setText("Salvar");
        botaoEntradaSalvar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoEntradaSalvarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
            .addComponent(jTabbedPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botaoEntradaSalvar)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(botaoEntradaSalvar)
                .addContainerGap())
        );

        abasPrincipais.addTab("Entrada", jPanel2);

        botaoSaidaSalvar.setText("Salvar");
        botaoSaidaSalvar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botaoSaidaSalvarMouseClicked(evt);
            }
        });

        jLabel27.setText("Placa");

        jLabel28.setText("Modelo");

        jLabel32.setText("Cor");

        jLabel33.setText("Marca");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel28)
                            .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(dispSaidaModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dispSaidaCor, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27)
                            .addComponent(jLabel33))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dispSaidaMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dispSaidaPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(544, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(dispSaidaPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dispSaidaMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel33))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(dispSaidaModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(dispSaidaCor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jTabbedPane7.addTab("Veículo", jPanel10);

        jLabel34.setText("Entrada");

        dispSaidaTipoVaga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Comum", "Deficiente", "Idoso", "Grávida", "Todas" }));

        dispSaidaVaga.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel35.setText("Tipo Vaga");

        jLabel36.setText("Vaga");

        jLabel37.setText("Uso");

        jLabel38.setText("Valor Hora");

        jLabel39.setText("Tolerância");

        inputSaidaSaida.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inputSaidaSaidaMouseClicked(evt);
            }
        });

        jLabel40.setText("Saída");

        dispSaidaTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dispSaidaTotalActionPerformed(evt);
            }
        });

        jLabel41.setText("Total");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel35)
                            .addComponent(jLabel36, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel34, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(dispSaidaTipoVaga, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(dispSaidaVaga, javax.swing.GroupLayout.Alignment.LEADING, 0, 206, Short.MAX_VALUE))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(dispSaidaEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel40)
                                .addGap(9, 9, 9)
                                .addComponent(inputSaidaSaida, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel39)
                            .addComponent(jLabel37))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dispSaidaTolerancia, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(dispSaidaUso, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(jLabel38)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(dispSaidaValorHora, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 216, Short.MAX_VALUE)
                                .addComponent(jLabel41)
                                .addGap(9, 9, 9)
                                .addComponent(dispSaidaTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(118, 118, 118))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(dispSaidaEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel40)
                    .addComponent(inputSaidaSaida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(dispSaidaTipoVaga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dispSaidaVaga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel36))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(dispSaidaTolerancia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jLabel38)
                    .addComponent(dispSaidaValorHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dispSaidaUso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41)
                    .addComponent(dispSaidaTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jTabbedPane8.addTab("Registro", jPanel11);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane7)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botaoSaidaSalvar)
                .addContainerGap())
            .addComponent(jTabbedPane8)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(7, Short.MAX_VALUE)
                .addComponent(jTabbedPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botaoSaidaSalvar)
                .addContainerGap())
        );

        abasPrincipais.addTab("Saída", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(abasPrincipais)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(abasPrincipais, javax.swing.GroupLayout.PREFERRED_SIZE, 478, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
      
    private void abasPrincipaisFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_abasPrincipaisFocusLost
        //System.out.println("OFF");        // TODO add your handling code here:
    }//GEN-LAST:event_abasPrincipaisFocusLost

    private void abasPrincipaisFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_abasPrincipaisFocusGained
        int aba = abasPrincipais.getSelectedIndex();
        
        dispSaidaEntrada.setText("");
        dispSaidaPlaca.setText("");
        dispSaidaUso.setText("");
        dispSaidaValorHora.setText("");
        dispSaidaTotal.setText("");
        dispSaidaTipoVaga.setSelectedItem("");
        dispSaidaCor.setText("");
        dispSaidaMarca.setText("");
        dispSaidaModelo.setText("");
        inputSaidaSaida.setText("");        
        dispEntradaTolerncia.setText("");
        dispEntradaUso.setText("");
        dispEntradaValorHora.setText("");
        inputEntradaCor.setText("");
        inputEntradaEntrada.setText("");
        inputEntradaMarca.setText("");
        inputEntradaModelo.setText("");
        inputEntradaPlaca.setText("");
        
        switch (aba) {                            
            case 2 ->                 {
                    
                    int indice = dispTabelaVagas.getSelectedRow();
                    if (indice >= 0){
                        TableModel model = (TableModel) dispTabelaVagas.getModel();                    
                        String estado = model.getValueAt(indice,4).toString();
                        if ("Ocupado".equals(estado)){

                            String placa = model.getValueAt(indice,5).toString();

                            Registro reg = new Registro(0);
                            ArrayList<Registro> registros = reg.getRegistro("SELECT * from registro where registro.placa = '" + placa + "'");

                            dispSaidaEntrada.setText(registros.get(0).getHoraEntrada().toString());
                            dispSaidaPlaca.setText(registros.get(0).getPlaca());
                            dispSaidaUso.setText(registros.get(0).getValorUso().toString());
                            dispSaidaValorHora.setText(registros.get(0).getHoraAdicional().toString());
                            dispSaidaTotal.setText(registros.get(0).getTotal().toString());

                            Vaga vg = new Vaga(0);
                            ArrayList<Vaga> vagas = vg.getVagas("SELECT * from vaga WHERE vaga.id = " + registros.get(0).getIdVaga().toString());

                            dispSaidaTipoVaga.setSelectedItem(vagas.get(0).getTipo());
                            dispSaidaVaga.setSelectedItem(vagas.get(0).getNumero().toString());

                            Carros car = new Carros("");
                            ArrayList<Carros> carro = car.getCarros("SELECT * from carros where carros.placa = '" + placa + "'");

                            dispSaidaCor.setText(carro.get(0).getCor());
                            dispSaidaMarca.setText(carro.get(0).getMarca());
                            dispSaidaModelo.setText(carro.get(0).getModelo());                       

                        }   
                    }
                    else{
                        abasPrincipais.setSelectedIndex(0);
                    }
                }
            case 1 ->                 {
                
                int indice = dispTabelaVagas.getSelectedRow();
                if (indice >= 0){
                    TableModel model = (TableModel) dispTabelaVagas.getModel();
                    String numVaga = model.getValueAt(indice,2).toString();
                    Vaga vg = new Vaga(0);
                    ArrayList<Vaga> vagas = vg.getVagas("SELECT * from vaga WHERE vaga.numero = " +numVaga);
                    selectEntradaVaga.setSelectedItem(vagas.get(0).getNumero().toString());
                    selectEntradaTipoVaga.setSelectedItem(vagas.get(0).getTipo());
                }                
            }
            default -> /* Aba 0 */
                PopulaVagas();
        }
    }//GEN-LAST:event_abasPrincipaisFocusGained

    private void dispSelectEstadoVagaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dispSelectEstadoVagaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dispSelectEstadoVagaActionPerformed

    private void dispVagasOcupadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dispVagasOcupadasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dispVagasOcupadasActionPerformed

    private void dispSelectTipoVagaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dispSelectTipoVagaActionPerformed
        
    }//GEN-LAST:event_dispSelectTipoVagaActionPerformed

    private void dispTabelaVagasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dispTabelaVagasMouseClicked
        int indice = dispTabelaVagas.getSelectedRow();
        
        TableModel model = (TableModel) dispTabelaVagas.getModel();
        
        String estado = model.getValueAt(indice,4).toString();
        
        if ("Ocupado".equals(estado)){
            abasPrincipais.setSelectedIndex(2);
        }
        else{
            abasPrincipais.setSelectedIndex(1);            
        }
        
    }//GEN-LAST:event_dispTabelaVagasMouseClicked

    private void dispSaidaTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dispSaidaTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dispSaidaTotalActionPerformed

    private void inputEntradaPlacaInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_inputEntradaPlacaInputMethodTextChanged
        
        
    }//GEN-LAST:event_inputEntradaPlacaInputMethodTextChanged

    private void inputEntradaPlacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputEntradaPlacaActionPerformed
        
    }//GEN-LAST:event_inputEntradaPlacaActionPerformed

    private void inputEntradaEntradaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inputEntradaEntradaMouseClicked
        LocalTime time = LocalTime.now();        
        inputEntradaEntrada.setText(Integer.toString(time.getHour()) + ":" + Integer.toString(time.getMinute()) + ":" + Integer.toString(time.getSecond()));
        
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found " + e);
        }
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM taxas");
        
            while (rs.next()) {
                
                dispEntradaTolerncia.setText(Integer.toString(rs.getInt("tolerancia")));
                dispEntradaUso.setText(rs.getString("valor_uso"));
                dispEntradaValorHora.setText(rs.getString("adicional_hora"));                
            
            }
            
        } catch (SQLException e) {
            System.out.println("SQL exception occured" + e);
        }
        
    }//GEN-LAST:event_inputEntradaEntradaMouseClicked

    private void inputSaidaSaidaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inputSaidaSaidaMouseClicked
        LocalTime time = LocalTime.now();        
        inputSaidaSaida.setText(Integer.toString(time.getHour()) + ":" + Integer.toString(time.getMinute()) + ":" + Integer.toString(time.getSecond()));
    }//GEN-LAST:event_inputSaidaSaidaMouseClicked

    private void botaoEntradaSalvarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoEntradaSalvarMouseClicked
        
        Vaga vg = new Vaga(0);
        ArrayList<Vaga> vagas = vg.getVagas("SELECT * FROM vaga WHERE vaga.numero = " + selectEntradaVaga.getSelectedItem().toString());
        
        if (!vagas.isEmpty()){
        
            Registro reg = new Registro(vagas.get(0).getId(), inputEntradaPlaca.getText(), inputEntradaMarca.getText(), inputEntradaCor.getText(), inputEntradaModelo.getText());
            reg.registrar_entrada(); 
            
            alertBox retorno = new alertBox("Registro de entrada efetuado com sucesso.");
            retorno.setVisible(true);
            
            PopulaVagas();
            abasPrincipais.setSelectedIndex(0);
            
        }
        
        
    }//GEN-LAST:event_botaoEntradaSalvarMouseClicked

    private void botaoSaidaSalvarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botaoSaidaSalvarMouseClicked
        // TODO add your handling code here:
        Registro reg = new Registro();
        
        Taxas tax = new Taxas();
        ArrayList<Taxas> taxas = tax.getTaxa("SELECT * FROM taxas");        
               
        reg.setPlaca(dispSaidaPlaca.getText());
        reg.registrar_saida();
        
        ArrayList<Registro> registros = reg.getRegistro("SELECT * FROM registro WHERE registro.placa = '" + dispSaidaPlaca.getText() + "' ORDER BY registro.dia_saida desc, registro.hora_saida desc LIMIT 1;");        
        
        if (!registros.isEmpty()){
            
            inputSaidaSaida.setText(registros.get(0).getHoraSaida().toString());
            dispSaidaTotal.setText(registros.get(0).getTotal().toString());
            dispSaidaTolerancia.setText(Integer.toString(taxas.get(0).getTolerancia()));
            
            alertBox retorno = new alertBox("Registro de saída efetuado com sucesso.");
            retorno.setVisible(true);                           
            
            PopulaVagas();
            abasPrincipais.setSelectedIndex(0);
                        
        }
        
    }//GEN-LAST:event_botaoSaidaSalvarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true); 
                
            }
        });     
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane abasPrincipais;
    private javax.swing.JButton botaoEntradaSalvar;
    private javax.swing.JButton botaoSaidaSalvar;
    private javax.swing.JTextField dispEntradaTolerncia;
    private javax.swing.JTextField dispEntradaUso;
    private javax.swing.JTextField dispEntradaValorHora;
    private javax.swing.JTextField dispSaidaCor;
    private javax.swing.JTextField dispSaidaEntrada;
    private javax.swing.JTextField dispSaidaMarca;
    private javax.swing.JTextField dispSaidaModelo;
    private javax.swing.JTextField dispSaidaPlaca;
    private javax.swing.JComboBox<String> dispSaidaTipoVaga;
    private javax.swing.JTextField dispSaidaTolerancia;
    private javax.swing.JTextField dispSaidaTotal;
    private javax.swing.JTextField dispSaidaUso;
    private javax.swing.JComboBox<String> dispSaidaVaga;
    private javax.swing.JTextField dispSaidaValorHora;
    private javax.swing.JComboBox<String> dispSelectEstadoVaga;
    private javax.swing.JComboBox<String> dispSelectTipoVaga;
    private javax.swing.JTable dispTabelaVagas;
    private javax.swing.JTextField dispTotalVagas;
    private javax.swing.JTextField dispVagasLivres;
    private javax.swing.JTextField dispVagasOcupadas;
    private javax.swing.JTextField inputEntradaCor;
    private javax.swing.JTextField inputEntradaEntrada;
    private javax.swing.JTextField inputEntradaMarca;
    private javax.swing.JTextField inputEntradaModelo;
    private javax.swing.JTextField inputEntradaPlaca;
    private javax.swing.JTextField inputSaidaSaida;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JTabbedPane jTabbedPane7;
    private javax.swing.JTabbedPane jTabbedPane8;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JComboBox<String> selectEntradaTipoVaga;
    private javax.swing.JComboBox<String> selectEntradaVaga;
    // End of variables declaration//GEN-END:variables

    
}
