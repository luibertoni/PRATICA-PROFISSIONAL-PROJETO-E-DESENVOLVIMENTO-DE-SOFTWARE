/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estacionamento;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Luigi
 */
@Entity
@Table(catalog = "postgres", schema = "POSTGRES")
@NamedQueries({
    @NamedQuery(name = "Taxas.findAll", query = "SELECT t FROM Taxas t"),
    @NamedQuery(name = "Taxas.findByValorUso", query = "SELECT t FROM Taxas t WHERE t.valorUso = :valorUso"),
    @NamedQuery(name = "Taxas.findByAdicionalHora", query = "SELECT t FROM Taxas t WHERE t.adicionalHora = :adicionalHora"),
    @NamedQuery(name = "Taxas.findByTolerancia", query = "SELECT t FROM Taxas t WHERE t.tolerancia = :tolerancia"),
    @NamedQuery(name = "Taxas.findById", query = "SELECT t FROM Taxas t WHERE t.id = :id")})
public class Taxas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "valor_uso", nullable = false)
    private double valorUso;
    @Basic(optional = false)
    @Column(name = "adicional_hora", nullable = false)
    private double adicionalHora;
    @Basic(optional = false)
    @Column(nullable = false)
    private int tolerancia;
    @Id
    @Basic(optional = false)
    @Column(nullable = false)
    private Short id;

    public Taxas() {
    }

    public Taxas(Short id) {
        this.id = id;
    }

    public Taxas(Short id, double valorUso, double adicionalHora, int tolerancia) {
        this.id = id;
        this.valorUso = valorUso;
        this.adicionalHora = adicionalHora;
        this.tolerancia = tolerancia;
    }

    public double getValorUso() {
        return valorUso;
    }

    public void setValorUso(double valorUso) {
        this.valorUso = valorUso;
    }

    public double getAdicionalHora() {
        return adicionalHora;
    }

    public void setAdicionalHora(double adicionalHora) {
        this.adicionalHora = adicionalHora;
    }

    public int getTolerancia() {
        return tolerancia;
    }

    public void setTolerancia(int tolerancia) {
        this.tolerancia = tolerancia;
    }

    public Short getId() {
        return id;
    }

    public void setId(Short id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Taxas)) {
            return false;
        }
        Taxas other = (Taxas) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "estacionamento.Taxas[ id=" + id + " ]";
    }
    
}
